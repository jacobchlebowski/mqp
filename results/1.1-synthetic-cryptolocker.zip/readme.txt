3/4 critical IOCs for synthetic cryptolocker
-1) tor2web connection attempt
-2) file encryption
-3) code obfuscation

